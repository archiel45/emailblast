 <?php
         
         // define variables and set to empty values
         $name = $email = $gender = $comment = $website = "";
         
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $email_add = test_input($_POST["email_add"]);
            $subject_to = test_input($_POST["subject_to"]);
            $Message = test_input($_POST["Message"]);
            $fileupload = test_input($_POST["fileupload"]);
			$email_java = test_input($_POST["email_java"]);
          
         }
         
         function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
      
	  
	    echo "<h2>Your Given details are as :</h2>";
         echo $email_add;
         echo "<br>";
         
         echo $subject_to;
         echo "<br>";
         
         echo $Message;
         echo "<br>";
         
         echo $fileupload;
         echo "<br>";
		 
		 echo $email_java;
         echo "<br>";
		 
		 
 