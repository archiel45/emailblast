<?php
session_destroy();
header("Location:http://localhost/emailblast/index.php");
	
?>