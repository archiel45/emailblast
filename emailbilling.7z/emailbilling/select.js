
var submit_button = $('#select');

submit_button.click(function() {

    var emailadd = $('email').val();
    

    alert(emailadd);
    }