<!DOCTYPE html>
<?php
require 'connect.php';



?>
<html>
<head>
	<title>Email Blast</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   	<link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="form.js"></script>
      
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   
	<!--<script type="text/javascript" >
      $(document).ready(function(){
        $('.add_more').click(function(e){
          e.preventDefault();
          $(this).before("<input name='file[]' multiple='multiple' type='file'/>");
        }); 
	
      });
    </script>-->
	<script type="text/javascript" src="tinymce/js/tinymce/tinymce.min.js"></script>
<!-- Just be careful that you give correct path to your tinymce.min.js file, above is the default example -->
<script>
    tinymce.init({
        selector: "textarea#elm1",
        theme: "modern",
		resize: false,
        width: '100%',
        height: '690',
        plugins: [
             "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
             "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
             "save table contextmenu directionality emoticons template paste textcolor",
       ],
       content_css: "css/content.css",
       toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons", 
       style_formats: [
            {title: 'Bold text', inline: 'b'},
            {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
            {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
            {title: 'Example 1', inline: 'span', classes: 'example1'},
            {title: 'Example 2', inline: 'span', classes: 'example2'},
            {title: 'Table styles'},
            {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ]
		
    }); 
</script>  

</head>
<body>

<div class="container-fluid" >    
	<div class="row">    
		
		<nav class="navbar navbar-inverse" style="margin-bottom: 0;">
			<div class="container-fluid">
				<div class="navbar-header" >
					
					<p ><font color="white"><h3>Email Blast System</h3></font></p>
					
				</div>
			</div>
		</nav>
	</div>
	
<form action="send.php"  method="POST" >    
<div class="row" style="height:800px;padding-bottom:0px;" > 
	
		<div class="col-sm-3" id="left" style="height:800px;padding-left:0px;padding-right:0px;padding-bottom:0px;margin-bottom:0px ;"> 
			
			<!-- Recipient  -->

				<div class="well" style="background-color:#e1e5ed;height:750px;padding-top:0px;padding-bottom:0px;padding-left:0.5px;padding-right:0.5px;margin-bottom:0px;" >
				
   					<div class="well well-sm" style="border: 1px solid white;background-color:#b3b3b3;margin-bottom: 0px;">
    					<button type="submit"   class="btn btn-primary"/><strong>SEND	</strong></button>
    					</div>
    				<div class="well well-sm" style="margin-bottom: 0px;background-color:#e1e5ed;">
						<button type="button" class="btn btn-default" data-toggle="modal" data-target="#opencontacts">Open Contacts</button>
						<button type="button" class="btn btn-default" data-toggle="modal" data-target="#addcontacts">Add Contacts</button>
						<input type="button" id='add' value="Add Contacts"  class="btn btn-default"   onclick="addRecipient()"/>
					</div>
						<!--<div class="recipient">
							<label for="exampleInputEmail1"><h4>To:</h4></label>
							<input type="email" name="email[]" class="form-control" id="email" placeholder="Email"/>
							<input name='file[]' multiple='multiple' type='file'/>
							<input type='button' class='btn-danger' value="Remove" style="margin-left:210px;"/>
							</div>-->

    				
   
   					<label for="exampleInputEmail1"><h4>To:</h4></label>
  					<!--<input type="button" id='add' value="Add Recipeint"  class="btn btn-default "   onclick="addRecipient()"/>-->
  					<div class="form-group" style="overflow-y: scroll;height:82%;background-color:white;padding-left:1px;">
						
					
					
					<span id="myForm" style="margin-left:1px;">

								</span>
					
						</div>
			
						
					
				</div>

		</div>


	  

		<div class="col-sm-9" id="right" style="height:800px;padding-left:0px;padding-right:0px;padding-bottom:0px;">
       		<div class="form-group" style="height:800px;">
       			
				<textarea id="elm1" name="area" style="height:100%;resize: none;"></textarea>

       		</div>
		</div>
	
	</form>


<!-- Modal -->
<div id="opencontacts" class="modal fade" role="dialog" >
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Contacts</h4>
      </div>
      <div class="modal-body" style="height:500px;">
		<div class="form-group" style="overflow-y: scroll;">
      <form id="viewcontacts" method="POST" >

        <?php
        	$query=mysqli_query($con,"SELECT * FROM contacts");

        	while($rows=mysqli_fetch_assoc($query)){

    		 echo "<input type='checkbox' name='email[]' value=".$rows['c_email'].">".$rows['c_email']."<br>";
    		 
        	}

        	
       
        ?>
        
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" id="select" class="btn btn-default"  >Select</button>
        </form>
      </div>
      <script>
    
</script>
    </div>

  </div>
</div>
<div id="addcontacts" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
       
      </div>
      <div class="modal-body">
        <p>asdasdasdodal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</div>

		

</body>
</html>